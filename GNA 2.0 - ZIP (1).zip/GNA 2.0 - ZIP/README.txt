in order to run GNA,
steps:

1. run SetUp.exe

2. wait for file creation.

3. open GNA.html with google chrome







-Yunus Emre Vurgun